<?php
define('BASEURL', $_SERVER['DOCUMENT_ROOT'] . '/xpto/');
	
define('PROOT', '/xpto/');

define ('COINCAP_APIKEY', $_ENV['COINCAP_APIKEY']);
